using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace ANPUA
{
    public struct ANPUA_NodeLink_Animation {}
}
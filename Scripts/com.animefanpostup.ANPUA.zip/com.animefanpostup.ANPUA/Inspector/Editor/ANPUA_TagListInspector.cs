using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

namespace ANPUA
{
    [CustomEditor(typeof(ANPUA_TagList))]
    public class ANPUA_TagListInspector : Editor
    {
        public override void OnInspectorGUI()
        {
            ANPUA_TagList myTarget = (ANPUA_TagList)target;

            myTarget.title = EditorGUILayout.TextField("Title", myTarget.title);
            myTarget.menuIcon = (Texture2D)EditorGUILayout.ObjectField("Menu Icon", myTarget.menuIcon, typeof(Texture2D), false);

            EditorGUILayout.Space(15);


            EditorGUILayout.BeginVertical("Box");
            foreach (ANPUA_TagGroup taggroup in myTarget.taggroups)
            {

                taggroup.title = EditorGUILayout.TextField("Group Title", taggroup.title);
                EditorGUILayout.Space(5);
                DrawTagGroup(taggroup);
            }
            EditorGUILayout.EndVertical();

            if (GUILayout.Button("Add Group"))
            {
                ANPUA_TagGroup newtaggroup = new ANPUA_TagGroup();
                ArrayUtility.Add<ANPUA_TagGroup>(ref myTarget.taggroups, newtaggroup);
            }

        }



        //Function to Draw Taglist
        public void DrawTagGroup(ANPUA_TagGroup taggroup)
        {
            EditorGUILayout.BeginHorizontal();
            {
                EditorGUILayout.LabelField("Menu Title");
                EditorGUILayout.LabelField("Name");
            }
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.BeginVertical("Box");
            foreach (ANPUA_Tag tag in taggroup.tags)
            {
                //Horizontal Layout for each Tag
                EditorGUILayout.BeginHorizontal();
                {
                    tag.title = EditorGUILayout.TextField(tag.title);
                    tag.name = EditorGUILayout.TextField(tag.name);
                    //X Button to remove the Tag
                    if (GUILayout.Button("X"))
                    {
                        ArrayUtility.Remove<ANPUA_Tag>(ref taggroup.tags, tag);
                    }
                }
                EditorGUILayout.EndHorizontal();

            }
            EditorGUILayout.EndVertical();
            EditorGUILayout.Space(15);

            EditorGUILayout.BeginHorizontal();
            {

                //Flexible Space
                GUILayout.FlexibleSpace();
                if (GUILayout.Button("Add Tag"))
                {
                    ANPUA_Tag newtag = new ANPUA_Tag();
                    ArrayUtility.Add<ANPUA_Tag>(ref taggroup.tags, newtag);
                }
            }
            EditorGUILayout.EndHorizontal();



        }
    }
}

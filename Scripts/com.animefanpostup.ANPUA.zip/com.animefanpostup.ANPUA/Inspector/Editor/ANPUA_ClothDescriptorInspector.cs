using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

namespace ANPUA
{

    [CustomEditor(typeof(ANPUA_ClothingSetDescriptor))]
    public class ANPUA_ClothDescriptorInspector : Editor
    {



        public override void OnInspectorGUI()
        {
            ANPUA_ClothingSetDescriptor myTarget = (ANPUA_ClothingSetDescriptor)target;
            EditorGUILayout.LabelField("Clothing Set Descriptor");

            myTarget.group_title = EditorGUILayout.TextField("Group Title", myTarget.group_title);
            myTarget.menuIcon = (Texture2D)EditorGUILayout.ObjectField("Menu Icon", myTarget.menuIcon, typeof(Texture2D), false);
            myTarget.mode = (ANPUA_ClothingGenMode)EditorGUILayout.EnumPopup("Mode", myTarget.mode);

            EditorGUILayout.Space(15);
            myTarget.tagList = CheckTagList(myTarget.tagList);

            EditorGUILayout.Space(15);
            EditorGUILayout.LabelField("Descriptor Elements");
            foreach (Transform child in myTarget.transform)
            {
                ANPUA_ClothingSetDescriptorElement element = child.GetComponent<ANPUA_ClothingSetDescriptorElement>();
                if (element != null)
                {
                    DrawDescriptorElementBox(element, myTarget.tagList);
                    CreateTask(element);
                    foreach(ANPUA_Task task in element.tasks)
                    {
                        DrawTask(task);
                    }
        
                }
            }


            //Button to Add a new Element
            if (GUILayout.Button("Add Element"))
            {
                GameObject go = new GameObject("Element");
                go.AddComponent<ANPUA_ClothingSetDescriptorElement>();
                go.transform.parent = myTarget.transform;
                go.transform.SetAsLastSibling();

                EditorGUILayout.Space(15);
                EditorGUILayout.LabelField("Descriptor Elements");

                //get the element
                //ANPUA_ClothingSetDescriptorElement element = go.GetComponent<ANPUA_ClothingSetDescriptorElement>();
                //create Task
            }
        }


        //Create a Function to Draw a Box COntaining a Descriptor Element
        public void DrawDescriptorElementBox(ANPUA_ClothingSetDescriptorElement element, ANPUA_TagList tagList)
        {
            EditorGUILayout.BeginVertical("Box");
            element.title = EditorGUILayout.TextField("Title", element.title);


            EditorGUILayout.BeginHorizontal();
            element.tagname = EditorGUILayout.TextField("Tag", element.tagname);
            string selection = DrawTagDropdown(tagList);
            EditorGUILayout.EndHorizontal();
            if (selection != "") element.tagname = selection;

            //Display Lists of Tasks
            EditorGUILayout.LabelField("Tasks");


            EditorGUILayout.EndVertical();
        }

        //Ui for Taglist display
        public ANPUA_TagList CheckTagList(ANPUA_TagList tagList)
        {
            EditorGUILayout.LabelField("Tag List");
            if (tagList == null)
            {
                if (GUILayout.Button("Add Tag List"))
                {
                    GameObject go = new GameObject("TagList");
                    go.AddComponent<ANPUA_TagList>();
                    go.transform.parent = ((ANPUA_ClothingSetDescriptor)target).transform;
                    go.transform.SetAsLastSibling();
                    return go.GetComponent<ANPUA_TagList>();
                }
            }
            else
            {
                EditorGUILayout.ObjectField("Tag List", tagList, typeof(ANPUA_TagList), true);
            }
            return tagList;
        }


        public string DrawTagDropdown(ANPUA_TagList tagList)
        {
            if (tagList == null) return "";

            //Create Dropdown with all Tags, combine the Tag with thier group like "Group/Tag"
            List<string> tagNames = new List<string>();
            tagNames.Add("select");
            foreach (ANPUA_TagGroup tagGroup in tagList.taggroups)
            {
                if (tagGroup == null) continue;
                foreach (ANPUA_Tag tag in tagGroup.tags)
                {
                    if (tag == null) continue;
                    if (tag.title == "") continue;
                    if (tagGroup.title == "") continue;
                    tagNames.Add(tagGroup.title + "/" + tag.title);
                }
            }

            //Create a string array from the list
            string[] tagNamesArray = tagNames.ToArray();

            //Create a dropdown with the tagNamesArray
            int selected = 0;
            selected = EditorGUILayout.Popup(selected, tagNamesArray, GUILayout.Width(40));

            //Return the selected tag
            if (selected == 0)
            {
                return "";
            }
            return tagNamesArray[selected];
        }

        //Function to draw Task
        public void CreateTask(ANPUA_DescriptorElement element)
        {
            //if the element is null offer Options to create a new Task
            //The options for a Task are:  ANPUA_Task_Edit, ANPUA_Task_Animate_Switchstatement, ANPUA_Task_AnimateSingle
            if (element != null)
            {
               //Create Dropdown to Create a new Task
                string[] taskOptions = new string[] { "Create Task", "Edit", "Animate Switch Statement", "Animate Single" };
                int selected = 0;
                selected = EditorGUILayout.Popup(selected, taskOptions, GUILayout.Width(140));

                //Create a new Task based on the selection
                if (selected == 1)
                {
                    ANPUA_Task_Edit task= new ANPUA_Task_Edit();
                    ArrayUtility.Add<ANPUA_Task>(ref element.tasks, task);
                }
                else if (selected == 2)
                {
                    ANPUA_Task_Animate_Switchstatement task = new ANPUA_Task_Animate_Switchstatement();
                    ArrayUtility.Add<ANPUA_Task>(ref element.tasks, task);
                }
                else if (selected == 3)
                {
                    ANPUA_Task_AnimateSingle task = new ANPUA_Task_AnimateSingle();
                    ArrayUtility.Add<ANPUA_Task>(ref element.tasks, task);
                }
             
            }
        }

        //Function to Draw Task
        public void DrawTask(ANPUA_Task task)
        {
            EditorGUILayout.BeginVertical("Box");
            EditorGUILayout.LabelField("Task");
            if (task is ANPUA_Task_Edit)
            {
                ANPUA_Task_Edit taskEdit = (ANPUA_Task_Edit)task;
                EditorGUILayout.LabelField("Task - Editfield");
            }
            else if (task is ANPUA_Task_Animate_Switchstatement)
            {
                ANPUA_Task_Animate_Switchstatement taskAnimate = (ANPUA_Task_Animate_Switchstatement)task;
                taskAnimate.altstates = new ANPUA_AlternateActionItem[0];
                EditorGUILayout.LabelField("Animate Switch Statement - Editfield");
            }
            else if (task is ANPUA_Task_AnimateSingle)
            {
                ANPUA_Task_AnimateSingle taskAnimate = (ANPUA_Task_AnimateSingle)task;
                //Placeholder label
                EditorGUILayout.LabelField("Animate Single - Editfield");
            }
            EditorGUILayout.EndVertical();
        }


    }
}


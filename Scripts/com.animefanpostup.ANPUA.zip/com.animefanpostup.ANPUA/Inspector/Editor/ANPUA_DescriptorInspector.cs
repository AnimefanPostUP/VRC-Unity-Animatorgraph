
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

namespace ANPUA
{
    [CustomEditor(typeof(ANPUA_AssetDescriptor))]
    public class ANPUA_DescriptorInspector : Editor
    {
        public override void OnInspectorGUI()
        {
           
        }
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using VRC.SDKBase;
using GraphProcessor;

namespace ANPUA
{

    public class ANPUA_AssetGraph : MonoBehaviour, IEditorOnly
    {
        public BaseGraph graphData;
    }
}
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using VRC.SDK3.Avatars.Components;
using VRC.SDK3.Avatars.ScriptableObjects;
using VRC.SDKBase;


namespace ANPUA
{
    [System.Serializable]
    public class ANPUA_ClothingSetDescriptor : MonoBehaviour, IEditorOnly
    {
      public string group_title;
      public Texture2D menuIcon;
      public ANPUA_TagList tagList;
      public ANPUA_ClothingGenMode mode;

      public ANPUA_ClothingSetDescriptorElement defaultElement;
      public ANPUA_ClothingSetDescriptorElement[] elements;
      public GameObject[] clothItems;
      
    }

    public  enum ANPUA_ClothingGenMode
    {
        TagAndSetMenus,
        OnlySetMenus,
        OnlyTagMenus
    }

}
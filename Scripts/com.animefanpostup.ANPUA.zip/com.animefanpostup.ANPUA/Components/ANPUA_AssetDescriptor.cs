using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using VRC.SDKBase;

//Namespace ANPUA
namespace ANPUA
{


    public class ANPUA_AssetDescriptor : ANPUA_Descriptor
    {
        public ANPUA_DescriptorElement[] elements;
        public string asset_title;
    }

}

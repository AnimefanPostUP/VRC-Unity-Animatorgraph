using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace ANPUA
{
    [System.Serializable]
    public class ANPUA_ClothingSetDescriptorElement : ANPUA_DescriptorElementTagged
    {
        public string iconpath;

        public string title;
        public GameObject[] clothItems;
    }


}
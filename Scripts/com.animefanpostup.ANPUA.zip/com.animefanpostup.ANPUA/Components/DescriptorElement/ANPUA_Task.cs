using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ANPUA
{
    [System.Serializable]
    public class ANPUA_Task
    {

    
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ANPUA
{
    public class ANPUA_MenuTarget
    {
        //Interface for "getMenuObject
        public GameObject getMenuObject()
        {
            return null;
        }
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using VRC.SDKBase;

//Namespace ANPUA
namespace ANPUA
{


    public class ANPUA_Action_Clip: ANPUA_Action
    {
        public AnimationClip clip;
        public ANPUA_AnimationAppend[] actions;

    }

}

    using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using VRC.SDKBase;

//Namespace ANPUA
namespace ANPUA
{

    [System.Serializable]
    public class ANPUA_Task_Animate_Switchstatement : ANPUA_Task_AnimateSingle
    {
        public ANPUA_AlternateActionItem[] altstates;
    }

}

    using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using VRC.SDKBase;

//Namespace ANPUA
namespace ANPUA
{

    [System.Serializable]
    public class ANPUA_Task_AnimateSingle : ANPUA_Task
    {
        public ANPUA_Action animation;
    }

}

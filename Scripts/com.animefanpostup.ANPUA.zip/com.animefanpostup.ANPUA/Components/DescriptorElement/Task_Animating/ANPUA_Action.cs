using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using VRC.SDKBase;

//Namespace ANPUA
namespace ANPUA
{

    [System.Serializable]
    public class ANPUA_Action
    {
        public ANPUA_SubstateMode condition;
        public ANPUA_SubstateMode mode;
    }

}

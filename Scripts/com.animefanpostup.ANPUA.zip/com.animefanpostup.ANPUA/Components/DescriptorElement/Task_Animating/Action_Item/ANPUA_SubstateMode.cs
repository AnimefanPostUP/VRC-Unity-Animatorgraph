using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using VRC.SDKBase;

//Namespace ANPUA
namespace ANPUA
{


    public enum ANPUA_SubstateMode 
    {
     Standard,
     ByDefaults
    }

   

}

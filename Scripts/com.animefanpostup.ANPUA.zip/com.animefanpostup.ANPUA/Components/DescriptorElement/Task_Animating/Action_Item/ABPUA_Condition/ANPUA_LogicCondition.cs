using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using VRC.SDKBase;

//Namespace ANPUA
namespace ANPUA
{

    [System.Serializable]
    public class ANPUA_LogicCondition
    {
        public ANPUA_LogicConditionType conditionType;
    }

    public enum ANPUA_LogicConditionType
    {
        ByVariable,
        Gesture
    }
}

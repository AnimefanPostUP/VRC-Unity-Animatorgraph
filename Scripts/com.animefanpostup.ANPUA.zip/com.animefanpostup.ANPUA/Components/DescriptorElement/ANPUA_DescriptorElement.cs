using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using VRC.SDKBase;

namespace ANPUA
{

    public class ANPUA_DescriptorElement : MonoBehaviour, IEditorOnly
    {
        public ANPUA_Task[] tasks = new ANPUA_Task[0];
    }
}

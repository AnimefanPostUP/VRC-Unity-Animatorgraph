using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace ANPUA
{
    [System.Serializable]
    public class ANPUA_DescriptorElementTagged : ANPUA_DescriptorElement
    {
        public string tagname;
    }


}
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using VRC.SDKBase;

//Namespace ANPUA
namespace ANPUA
{


    public class ANPUA_Descriptor
    {
        public ANPUA_DescriptorElement[] elements;
    }

}

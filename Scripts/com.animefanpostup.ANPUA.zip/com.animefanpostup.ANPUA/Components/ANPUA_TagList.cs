using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using VRC.SDKBase;

//Namespace ANPUA
namespace ANPUA
{

    [System.Serializable]
    public class ANPUA_TagList : MonoBehaviour, IEditorOnly
    {

        public string title = "";
        public Texture2D menuIcon;
        public ANPUA_TagGroup[] taggroups = new ANPUA_TagGroup[0];

    }

    [System.Serializable]
    public class ANPUA_TagGroup
    {
        public string title = "";
        public ANPUA_Tag[] tags = new ANPUA_Tag[0];
    }

    [System.Serializable]
    public class ANPUA_Tag
    {
        public string title = "";
        public string name = "";
    }
}
